// let imagemCenario;
let bg_clouds;
let bg_mountains;
let bg_trees;
let ground;

// let imagemPersonagem
let sprite;

let cenario;

let music;

let player;

function preload() {
  bg_clouds = loadImage('images/background/bg-clouds.png');
  bg_mountains = loadImage('images/background/bg-mountains.png');
  bg_trees = loadImage('images/background/bg-trees.png');
  bg_ground = loadImage('images/background/ground.png');
  sprite = loadImage('images/player/sprites.png');
  music = loadSound('sounds/the_valley.ogg');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  /* Na explicação foi utilizada apenas uma img de fundo, logo foi feito:
  cenario = new Cenario (bg_clouds, 50) */
  clouds = new Cenario (bg_clouds, .1);
  mountains = new Cenario (bg_mountains, .15);
  trees = new Cenario (bg_trees, .5);
  ground = new Cenario (bg_ground, 5);
  player = new Personagem (sprite);
  frameRate(25)
  // music.loop();
}

function draw() {
  /* Aqui viria o cenario.exibe() da explicação */
  clouds.exibe();
  clouds.move();
  mountains.exibe();
  mountains.move();
  trees.exibe();
  trees.move();
  ground.exibe();
  ground.move();
  player.exibe();
  
  /* Fora de uso:
  image(bg_clouds, -50, 0, width, height);
  image(bg_clouds, width -50, 0, width, height);
  image(bg_mountains,-50, 0, width, height); 
  image(bg_mountains, width -50, 0, width, height);
  image(bg_trees, -50, 0, width, height);
  image(bg_trees, width -50, 0, width, height);
  image(ground, -50, 0, 900, height);
  image(ground, width -50, 0, 900, height);
  */
  
}
  
